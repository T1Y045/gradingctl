#!/bin/bash

SERVER_URL="http://172.20.4.2:5000"
ACTIVE_LAB_FILE="/tmp/active_lab"

function login() {
    echo -n "Username: "
    read username
    echo -n "Password: "
    read -s password
    echo
    echo -n "Class Name: "
    read class_name

    RESPONSE=$(curl -s -X POST -H "Content-Type: application/json" \
    -d "{\"username\": \"$username\", \"password\": \"$password\", \"class_name\": \"$class_name\"}" \
    $SERVER_URL/login)

    TOKEN=$(echo "$RESPONSE" | jq -r '.token')

    if [[ $TOKEN == "null" || -z $TOKEN ]]; then
        echo "Login failed"
        exit 1
    else
        echo $TOKEN > ~/.nusactl_token
        echo "Login successful"
    fi
}

function start_lab() {
    TOKEN=$(cat ~/.nusactl_token)
    if [[ -z "$TOKEN" ]]; then
        echo "Error: Token not found. Please login first."
        exit 1
    fi

    LAB_ID=$1
    if [[ -z "$LAB_ID" ]]; then
        echo "Error: Lab ID is required."
        exit 1
    fi

    # Kirim request ke server
    RESPONSE=$(curl -s -X POST -H "Authorization: Bearer $TOKEN" \
        -H "Content-Type: application/json" \
        -d "{\"lab_id\": \"$LAB_ID\"}" \
        "$SERVER_URL/start-lab")

    # Debugging: Tampilkan respons dari server
    echo "Server response: $RESPONSE"

    # Periksa apakah ada error dalam respons
    ERROR=$(echo "$RESPONSE" | jq -r '.error')
    if [[ "$ERROR" != "null" && -n "$ERROR" ]]; then
        echo "Error: $ERROR"
        exit 1
    fi

    # Simpan lab yang aktif
    echo "$LAB_ID" > "$ACTIVE_LAB_FILE"
    echo "Lab started successfully: $LAB_ID"
}

function escape_json() {
    # Escape karakter kontrol dan karakter khusus dalam string JSON
    echo "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' -e 's/\x00/\\u0000/g' -e 's/\x01/\\u0001/g' \
    -e 's/\x02/\\u0002/g' -e 's/\x03/\\u0003/g' -e 's/\x04/\\u0004/g' -e 's/\x05/\\u0005/g' \
    -e 's/\x06/\\u0006/g' -e 's/\x07/\\u0007/g' -e 's/\x08/\\b/g' -e 's/\x09/\\t/g' \
    -e 's/\x0A/\\n/g' -e 's/\x0B/\\u000B/g' -e 's/\x0C/\\f/g' -e 's/\x0D/\\r/g' \
    -e 's/\x0E/\\u000E/g' -e 's/\x0F/\\u000F/g' -e 's/\x10/\\u0010/g' -e 's/\x11/\\u0011/g' \
    -e 's/\x12/\\u0012/g' -e 's/\x13/\\u0013/g' -e 's/\x14/\\u0014/g' -e 's/\x15/\\u0015/g' \
    -e 's/\x16/\\u0016/g' -e 's/\x17/\\u0017/g' -e 's/\x18/\\u0018/g' -e 's/\x19/\\u0019/g' \
    -e 's/\x1A/\\u001A/g' -e 's/\x1B/\\u001B/g' -e 's/\x1C/\\u001C/g' -e 's/\x1D/\\u001D/g' \
    -e 's/\x1E/\\u001E/g' -e 's/\x1F/\\u001F/g'
}

function grade_lab() {
    TOKEN=$(cat ~/.nusactl_token)
    LAB_ID=$1

    if [[ ! -f "$ACTIVE_LAB_FILE" || $(cat "$ACTIVE_LAB_FILE") != "$LAB_ID" ]]; then
        echo "Error: Lab not started. Please run 'start' first."
        exit 1
    fi

    # Ambil class_name dari token (asumsi class_name disimpan di token)
    CLASS_NAME=$(echo "$TOKEN" | cut -d'-' -f4)  # Sesuaikan dengan format token Anda

    # Ambil skema dari server
    SCHEME_RESPONSE=$(curl -s -X GET -H "Authorization: Bearer $TOKEN" \
    "$SERVER_URL/get-scheme?lab_id=$LAB_ID")

    SCHEME=$(echo "$SCHEME_RESPONSE" | jq -c '.scheme')
    if [[ -z "$SCHEME" || "$SCHEME" == "null" ]]; then
        echo "Error: Failed to fetch scheme for lab $LAB_ID"
        exit 1
    fi

    # Kumpulkan data sesuai skema
    declare -A DATA

    while IFS= read -r criterion; do
        TYPE=$(echo "$criterion" | jq -r '.type')
        KEY=$(echo "$criterion" | jq -r '.key')  # Gunakan 'key' sebagai identifier unik

        case $TYPE in
            command)
                COMMAND=$(echo "$criterion" | jq -r '.command')
                OUTPUT=$(eval "$COMMAND" 2>/dev/null || echo "Error: Command failed")
                # Bersihkan output dari karakter kontrol
                OUTPUT=$(echo "$OUTPUT" | tr -cd '\11\12\15\40-\176')
                DATA["$KEY"]="$OUTPUT"
                ;;
            file_exists)
                FILE_PATH=$(echo "$criterion" | jq -r '.path')
                EXPECTED=$(echo "$criterion" | jq -r '.expected')
                if [[ "$EXPECTED" == "deleted" ]]; then
                    if [[ ! -f "$FILE_PATH" ]]; then
                        DATA["$KEY"]="deleted"
                    else
                        DATA["$KEY"]="Error: File exists"
                    fi
                else
                    if [[ -f "$FILE_PATH" ]]; then
                        DATA["$KEY"]="exists"
                    else
                        DATA["$KEY"]="Error: File not found"
                    fi
                fi
                ;;
            file_content)
                FILE_PATH=$(echo "$criterion" | jq -r '.path')
                CONTAINS=$(echo "$criterion" | jq -r '.contains')
                echo "Checking file: $FILE_PATH"
                if [[ -f "$FILE_PATH" ]]; then
                    CONTENT=$(cat "$FILE_PATH" 2>/dev/null || echo "")
                    echo "File content: $CONTENT"
                    if [[ "$CONTENT" == *"$CONTAINS"* ]]; then
                        DATA["$KEY"]="contains"
                    else
                        DATA["$KEY"]="Error: Content not found"
                    fi
                else
                    DATA["$KEY"]="Error: File not found"
                fi
                ;;
            service)
                SERVICE_NAME=$(echo "$criterion" | jq -r '.service')
                if systemctl is-active --quiet "$SERVICE_NAME"; then
                    DATA["$KEY"]="active"
                else
                    DATA["$KEY"]="Error: Service not active"
                fi
                ;;
            directory)
                DIR_PATH=$(echo "$criterion" | jq -r '.path')
                if [[ -d "$DIR_PATH" ]]; then
                    DATA["$KEY"]="exists"
                else
                    DATA["$KEY"]="Error: Directory not found"
                fi
                ;;
            config_check)
                FILE_PATH=$(echo "$criterion" | jq -r '.path')
                PARAMETER=$(echo "$criterion" | jq -r '.parameter')
                EXPECTED=$(echo "$criterion" | jq -r '.expected')
                if [[ -f "$FILE_PATH" ]]; then
                    if [[ "$PARAMETER" == "owner" ]]; then
                        OWNER=$(stat -c "%U" "$FILE_PATH")
                        if [[ "$OWNER" == "$EXPECTED" ]]; then
                            DATA["$KEY"]="correct"
                        else
                            DATA["$KEY"]="Error: Incorrect owner"
                        fi
                    elif [[ "$PARAMETER" == "group" ]]; then
                        GROUP=$(stat -c "%G" "$FILE_PATH")
                        if [[ "$GROUP" == "$EXPECTED" ]]; then
                            DATA["$KEY"]="correct"
                        else
                            DATA["$KEY"]="Error: Incorrect group"
                        fi
                    elif [[ "$PARAMETER" == "permissions" ]]; then
                        PERM=$(stat -c "%A" "$FILE_PATH")
                        # Potong karakter pertama (misalnya '-') dari permission string
                        PERM=${PERM:1}
                        if [[ "$PERM" == "$EXPECTED" ]]; then
                            DATA["$KEY"]="correct"
                        else
                            DATA["$KEY"]="Error: Incorrect permissions"
                        fi
                    else
                        DATA["$KEY"]="Error: Invalid parameter"
                    fi
                else
                    DATA["$KEY"]="Error: File not found"
                fi
                ;;
            package)
                PACKAGE_NAME=$(echo "$criterion" | jq -r '.name')
                if dpkg -l | grep -q "^ii  $PACKAGE_NAME "; then
                    DATA["$KEY"]="installed"
                else
                    DATA["$KEY"]="Error: Package not installed"
                fi
                ;;
            user)
                USER_NAME=$(echo "$criterion" | jq -r '.name')
                if id "$USER_NAME" &>/dev/null; then
                    DATA["$KEY"]="exists"
                else
                    DATA["$KEY"]="Error: User not found"
                fi
                ;;
            group)
                GROUP_NAME=$(echo "$criterion" | jq -r '.name')
                if getent group "$GROUP_NAME" &>/dev/null; then
                    DATA["$KEY"]="exists"
                else
                    DATA["$KEY"]="Error: Group not found"
                fi
                ;;
            *)
                echo "Unsupported criterion type: $TYPE"
                exit 1
                ;;
        esac
    done < <(echo "$SCHEME" | jq -c '.criteria[]')

    # Buat JSON untuk request grading
    CLIENT_DATA=$(jq -n \
        --arg lab_id "$LAB_ID" \
        --arg class_name "$CLASS_NAME" \
        --argjson data "$(for key in "${!DATA[@]}"; do echo "{\"$key\": \"${DATA[$key]}\"}"; done | jq -s 'add')" \
        '{"lab_id": $lab_id, "class_name": $class_name, "client_data": $data}')

    # Debugging: Tampilkan data yang akan dikirim
    echo "Sending data to server: $CLIENT_DATA"

    # Kirim data ke server untuk grading
    RESPONSE=$(curl -s -X POST -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "$CLIENT_DATA" \
    "$SERVER_URL/grade-lab")

    # Tampilkan hasil grading dengan format yang lebih baik
    print_grading_result "$LAB_ID" "$RESPONSE"
}

# Fungsi untuk mencetak hasil grading yang terformat
function print_grading_result() {
    LAB_ID=$1
    RESPONSE=$2

    SCORE=$(echo "$RESPONSE" | jq -r '.score')
    FEEDBACK=$(echo "$RESPONSE" | jq -c '.feedback[]' 2>/dev/null || echo "")

    echo "[-] Grading lab -> $LAB_ID"

    if [[ -z "$FEEDBACK" ]]; then
        echo "    => All tasks completed successfully [✓]"
    else
        local i=1
        while IFS= read -r feedback; do
            echo "    => case $i - $feedback [x]"
            ((i++))
        done < <(echo "$FEEDBACK" | jq -r '.')
        echo "[x] Oh no! You didn't complete all the tasks yet"
    fi

    echo "[-] Score -> $SCORE"
    if [[ "$SCORE" == "100" ]]; then
        echo "[✓] Congratulations! You've completed the task!"
    else
        echo "[✓] Don't worry, we keep your higher score"
    fi
}

case $1 in
    login) login ;;
    start) start_lab $2 ;;
    grade) grade_lab $2 ;;
    *) echo "Usage: gradingctl {login|start|grade}" ;;
esac
